import { selections } from "./application-bindings.ts";
import { localLogins } from "./local-bindings.ts";



import type { ProcessScope } from "../runtime/process.ts";

export type ServiceBinding = {
	id: string;
	kind: string;
	host: string;
	identity?: string;
	inputs: Record<string, string | number>;
	resources: Record<string, string>;
};
export function selected(kind: string, id?: string): ServiceBinding {
	const rows = selections.filter(
		(s) => s.kind === kind && (!id || s.id === id),
	);
	if (rows.length !== 1) throw Error("Expected one selected responsibility");
	return rows[0]!;
}
export function input(s: ServiceBinding, key: string): number {
	const value = s.inputs[key];
	if (typeof value !== "number") throw Error(`Missing consumed setting ${key}`);
	return value;
}
export function resource(s: ServiceBinding, field: string): string {
	const id = s.resources[field];
	if (!id) throw Error(`Missing selected resource ${field}`);
	return id;
}



export function httpSettings(s: ServiceBinding) {
	return {
		requestTimeoutMs: input(s, "host.requestTimeoutMs"),
		concurrencyLimit: input(s, "host.concurrencyLimit"),
	};
}

