// My links, a Data access in Account API: Cursor pages (at most 50, by created_at and id) of the caller's own links from the Links owner view.
// Write the module here. Export never overwrites your edits: export afresh and carry them over.
import type { ModuleRequest, ModuleResponse } from "../entry.ts";
import type { Dependencies } from "./account-api-my-links.slots.ts";

/** Answers any method on /modules/account-api-my-links and every path below it. */
export async function accountApiMyLinks(dependencies: Dependencies, request: ModuleRequest): Promise<ModuleResponse> {
  throw new Error("Not implemented: My links");
}
